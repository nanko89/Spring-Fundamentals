package com.example.finalexam.model.view;

public class HomeAddSongModel {
    private Long songId;

    public HomeAddSongModel() {
    }

    public Long getSongId() {
        return songId;
    }

    public HomeAddSongModel setSongId(Long songId) {
        this.songId = songId;
        return this;
    }
}
