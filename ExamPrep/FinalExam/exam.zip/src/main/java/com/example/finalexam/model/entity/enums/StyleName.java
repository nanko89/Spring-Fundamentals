package com.example.finalexam.model.entity.enums;

public enum StyleName {
    POP,
    ROCK,
    JAZZ
}
